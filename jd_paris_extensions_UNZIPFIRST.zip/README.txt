Following extensions used in JD Paris

01. https://www.joomdev.com/products/extensions/jd-simple-contact-form
02. https://www.joomdev.com/products/extensions/jd-skillset
03. https://www.joomdev.com/products/extensions/jd-profiler
04. https://www.joomdev.com/products/extensions/register-login
05. https://smartslider3.com/free-joomla-slider/
06. https://www.acyba.com/acymailing.html
07. https://www.tzportfolio.com/download.html
