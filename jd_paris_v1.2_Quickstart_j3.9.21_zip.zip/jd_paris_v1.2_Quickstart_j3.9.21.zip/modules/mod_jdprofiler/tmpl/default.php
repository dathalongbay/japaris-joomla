<?php
defined('_JEXEC') or die;
// Licensed under the GPL v3  
//echo "<pre>";
//print_r($profiles);
?>
